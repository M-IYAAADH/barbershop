const API_URL = "http://localhost:5000/api/bookings"; // Change if using different backend port or deployed

// Create a booking
export async function createBooking(bookingData) {
  const response = await fetch(API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(bookingData)
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || "Failed to create booking");
  }

  return await response.json();
}

// (Optional) Get available slots
export async function getAvailableSlots(date) {
  const url = date ? `${API_URL}/available?date=${date}` : `${API_URL}/available`;
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error("Failed to fetch available slots");
  }

  return await response.json();
}
