import React from "react";
const About = () => (
  <section>
    <h2>About Us</h2>
    <p>We are a professional barbershop committed to great style and customer care.</p>
  </section>
);
export default About;
