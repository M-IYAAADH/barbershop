import React from "react";
const Gallery = () => (
  <section>
    <h2>Gallery</h2>
    <p>Some photos of our work will be displayed here.</p>
  </section>
);
export default Gallery;
