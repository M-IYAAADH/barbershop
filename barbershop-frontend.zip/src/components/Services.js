import React from "react";
const Services = () => (
  <section>
    <h2>Our Services</h2>
    <ul>
      <li>Classic Haircut</li>
      <li>Beard Trim</li>
      <li>Shave</li>
    </ul>
  </section>
);
export default Services;
