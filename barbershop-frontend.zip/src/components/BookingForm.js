import React, { useState } from "react";
import { createBooking } from "../api/bookings";

const BookingForm = () => {
  const [form, setForm] = useState({
    name: "",
    phone: "",
    date: ""
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    try {
      await createBooking(form);
      setMessage("Booking successful! We will contact you soon.");
      setForm({ name: "", phone: "", date: "" }); // Reset form
    } catch (err) {
      setMessage(err.message || "Booking failed. Please try again.");
    }
    setLoading(false);
  };

  return (
    <section>
      <h2>Book an Appointment</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Name"
          value={form.name}
          onChange={handleChange}
          required
        /><br />
        <input
          type="tel"
          name="phone"
          placeholder="Phone"
          value={form.phone}
          onChange={handleChange}
          required
        /><br />
        <input
          type="date"
          name="date"
          value={form.date}
          onChange={handleChange}
          required
        /><br />
        <button type="submit" disabled={loading}>
          {loading ? "Booking..." : "Book Now"}
        </button>
      </form>
      {message && <p>{message}</p>}
    </section>
  );
};

export default BookingForm;
