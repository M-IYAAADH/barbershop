import React from "react";
const Hero = () => (
  <section>
    <h2>Welcome to Our Barbershop</h2>
    <p>Experience classic cuts and modern style!</p>
  </section>
);
export default Hero;
