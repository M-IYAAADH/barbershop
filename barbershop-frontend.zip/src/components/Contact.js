import React from "react";
const Contact = () => (
  <section>
    <h2>Contact Us</h2>
    <p>Phone: (555) 123-4567</p>
    <p>Email: info@barbershop.com</p>
  </section>
);
export default Contact;
