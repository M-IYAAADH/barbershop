import React from "react";

const AdminDashboard = () => (
  <div>
    <h2>Admin Dashboard</h2>
    <p>Manage barbers, bookings, and more here.</p>
  </div>
);

export default AdminDashboard;
