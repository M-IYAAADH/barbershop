import React from "react";

const Home = () => (
  <div>
    <h1>Welcome to the Barbershop</h1>
    <p>This is the home page. Book your cut or explore our services!</p>
  </div>
);

export default Home;
