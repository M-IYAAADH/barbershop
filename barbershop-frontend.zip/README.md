# Barbershop Frontend

React frontend for the barbershop booking app.
