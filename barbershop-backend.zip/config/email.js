const nodemailer = require('nodemailer');

// Configure your email service (e.g., Gmail, SendGrid)
const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

exports.sendConfirmationEmail = async (booking) => {
  try {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: booking.customerEmail,
      subject: 'Your Barbershop Appointment Confirmation',
      html: `
        <h1>Your Appointment is Confirmed</h1>
        <p>Thank you for booking with us, ${booking.customerName}!</p>
        <h2>Appointment Details</h2>
        <p><strong>Service:</strong> ${booking.service}</p>
        <p><strong>Date:</strong> ${new Date(booking.date).toLocaleDateString()}</p>
        <p><strong>Time:</strong> ${booking.startTime} - ${booking.endTime}</p>
        <p>We look forward to seeing you!</p>
      `
    };

    await transporter.sendMail(mailOptions);
  } catch (err) {
    console.error('Error sending confirmation email:', err);
  }
};