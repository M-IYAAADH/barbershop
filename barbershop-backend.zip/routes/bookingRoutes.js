const express = require('express');
const router = express.Router();
const { validateBooking } = require('../middlewares/validate');
const {
  createBooking,
  getAvailableSlots,
  getBookings,
  getBooking,
  updateBooking,
  deleteBooking
} = require('../controllers/bookingController');

// Public routes
router.get('/available', getAvailableSlots);
router.post('/', validateBooking, createBooking);

// Protected routes (require admin auth)
router.use(require('../middlewares/auth'));
router.get('/', getBookings);
router.get('/:id', getBooking);
router.put('/:id', updateBooking);
router.delete('/:id', deleteBooking);

module.exports = router;
