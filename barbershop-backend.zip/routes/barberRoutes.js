const express = require('express');
const router = express.Router();
const {
  createBarber,
  getBarbers,
  getBarber,
  updateBarber,
  deleteBarber
} = require('../controllers/barberController');

// Public: Get all barbers or one barber
router.get('/', getBarbers);
router.get('/:id', getBarber);

// Protected (admin-only): Add, update, delete barbers
const auth = require('../middlewares/auth');
router.post('/', auth, createBarber);
router.put('/:id', auth, updateBarber);
router.delete('/:id', auth, deleteBarber);

module.exports = router;
