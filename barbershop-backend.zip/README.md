# Barbershop Backend

Node.js + Express backend for the barbershop booking app.
