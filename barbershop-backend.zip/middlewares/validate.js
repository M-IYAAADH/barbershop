module.exports = function (req, res, next) {
  // Example: Check required fields
  if (!req.body.customerName || !req.body.date || !req.body.time) {
    return res.status(400).json({ msg: 'Missing required fields' });
  }
  next();
};
