const Booking = require('../models/Booking');
const Barber = require('../models/Barber');
const { sendConfirmationEmail } = require('../config/email');

// Calculate available time slots
exports.getAvailableSlots = async (req, res) => {
  try {
    const { date, barberId, serviceDuration } = req.query;
    
    if (!date || !barberId) {
      return res.status(400).json({ error: 'Date and barber ID are required' });
    }

    const selectedDate = new Date(date);
    const barber = await Barber.findById(barberId);
    
    if (!barber) {
      return res.status(404).json({ error: 'Barber not found' });
    }

    // Get existing bookings for the selected date and barber
    const bookings = await Booking.find({
      barber: barberId,
      date: {
        $gte: new Date(selectedDate.setHours(0, 0, 0, 0)),
        $lte: new Date(selectedDate.setHours(23, 59, 59, 999))
      },
      status: { $ne: 'cancelled' }
    });

    // Generate all possible time slots for the barber's working hours
    const workingHours = barber.workingHours;
    const slotDuration = serviceDuration || 30; // default 30 minutes
    const slots = generateTimeSlots(workingHours.start, workingHours.end, slotDuration);

    // Filter out booked slots
    const availableSlots = slots.filter(slot => {
      return !bookings.some(booking => {
        return booking.startTime <= slot.end && booking.endTime >= slot.start;
      });
    });

    res.json({ availableSlots });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Create a new booking
exports.createBooking = async (req, res) => {
  try {
    const { customerName, customerPhone, customerEmail, barber, service, date, startTime, endTime, notes } = req.body;

    // Check if the slot is still available
    const conflictingBooking = await Booking.findOne({
      barber,
      date,
      startTime: { $lt: endTime },
      endTime: { $gt: startTime },
      status: { $ne: 'cancelled' }
    });

    if (conflictingBooking) {
      return res.status(400).json({ error: 'This time slot is no longer available' });
    }

    const booking = new Booking({
      customerName,
      customerPhone,
      customerEmail,
      barber,
      service,
      date,
      startTime,
      endTime,
      notes
    });

    await booking.save();
    
    // Send confirmation email
    await sendConfirmationEmail(booking);

    res.status(201).json(booking);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Helper function to generate time slots
function generateTimeSlots(startTime, endTime, duration) {
  const slots = [];
  const [startHour, startMinute] = startTime.split(':').map(Number);
  const [endHour, endMinute] = endTime.split(':').map(Number);
  
  let currentHour = startHour;
  let currentMinute = startMinute;
  
  while (currentHour < endHour || (currentHour === endHour && currentMinute < endMinute)) {
    const slotStart = `${String(currentHour).padStart(2, '0')}:${String(currentMinute).padStart(2, '0')}`;
    
    // Calculate end time
    let endHour = currentHour;
    let endMinute = currentMinute + duration;
    
    while (endMinute >= 60) {
      endMinute -= 60;
      endHour += 1;
    }
    
    const slotEnd = `${String(endHour).padStart(2, '0')}:${String(endMinute).padStart(2, '0')}`;
    
    slots.push({ start: slotStart, end: slotEnd });
    
    // Move to next slot (assuming 15-minute intervals between slots)
    currentMinute += 15;
    if (currentMinute >= 60) {
      currentMinute -= 60;
      currentHour += 1;
    }
  }
  
  return slots;
}