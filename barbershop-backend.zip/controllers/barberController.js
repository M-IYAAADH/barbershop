const Barber = require('../models/Barber');

// Get all barbers
exports.getBarbers = async (req, res) => {
  try {
    const barbers = await Barber.find();
    res.json(barbers);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get single barber by ID
exports.getBarber = async (req, res) => {
  try {
    const barber = await Barber.findById(req.params.id);
    if (!barber) return res.status(404).json({ error: 'Barber not found' });
    res.json(barber);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Create a new barber (admin only)
exports.createBarber = async (req, res) => {
  try {
    const { name, email, phone, workingHours, daysOff, services } = req.body;
    const newBarber = new Barber({ name, email, phone, workingHours, daysOff, services });
    await newBarber.save();
    res.status(201).json(newBarber);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Update barber details (admin only)
exports.updateBarber = async (req, res) => {
  try {
    const barber = await Barber.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!barber) return res.status(404).json({ error: 'Barber not found' });
    res.json(barber);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};

// Delete barber (admin only)
exports.deleteBarber = async (req, res) => {
  try {
    const barber = await Barber.findByIdAndDelete(req.params.id);
    if (!barber) return res.status(404).json({ error: 'Barber not found' });
    res.json({ message: 'Barber deleted' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
};
